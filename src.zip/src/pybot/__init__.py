'A simple Telegram bot for messaging.'

__version__ = '0.0.0rc1'
